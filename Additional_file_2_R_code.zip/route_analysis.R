## CKD-ROUTE illustrative application: diagnostic workflow of the paper
suppressPackageStartupMessages(library(survival))
d <- readRDS("route_analysis.rds")
covs <- c("age10","male","egfr10","lupcr","sbp10","diab","hb")
cont <- c("age10","egfr10","lupcr","sbp10","hb")
ctr  <- sapply(d[cont], mean); for (v in cont) d[[paste0(v,"_c")]] <- d[[v]] - ctr[v]
X_names <- c("age10_c","male","egfr10_c","lupcr_c","sbp10_c","diab","hb_c")
X <- as.matrix(d[, X_names]); tm <- d$time; st <- d$status
fml <- Surv(time, status) ~ age10_c + male + egfr10_c + lupcr_c + sbp10_c + diab + hb_c
out <- list()

## ---- M1 and PH diagnostics
m1 <- coxph(fml, data = d); out$M1 <- m1
zph <- cox.zph(m1, transform = "km"); out$zph <- zph
## time-specific (piecewise) hazard ratios for eGFR: 0-1, 1-2, >2 years
ds <- survSplit(fml, data = d, cut = c(1, 2), episode = "period")
mp <- coxph(Surv(tstart, time, status) ~ age10_c + male + lupcr_c + sbp10_c + diab + hb_c +
              egfr10_c:strata(period), data = ds)
out$piece <- summary(mp)$coefficients[grep("egfr", rownames(summary(mp)$coefficients)), ]
## ---- M2: tt(eGFR * log t)
m2 <- coxph(Surv(time, status) ~ age10_c + male + egfr10_c + lupcr_c + sbp10_c + diab + hb_c + tt(egfr10_c),
            data = d, tt = function(x, t, ...) x * log(t)); out$M2 <- m2
## ---- M3: Cox + individual gamma frailty (penalised)
m3 <- coxph(update(fml, . ~ . + frailty(ID, distribution = "gamma")), data = d); out$M3 <- m3
## ---- Cox + shared gamma frailty by hospital
m3h <- coxph(update(fml, . ~ . + frailty(hosp, distribution = "gamma")), data = d); out$M3h <- m3h

## ---- Parametric marginal likelihoods: baseline x frailty type
## baseline parameter blocks
bl <- list(
  weibull = list(k = 2, H0 = function(p, t) exp(p[1]) * t^exp(p[2]),
                 lh0 = function(p, t) p[1] + p[2] + (exp(p[2]) - 1) * log(t)),
  loglogistic = list(k = 2, H0 = function(p, t) log1p((t / exp(p[1]))^exp(p[2])),
                 lh0 = function(p, t) { s <- exp(p[1]); k <- exp(p[2]); log(k/s) + (k-1)*log(t/s) - log1p((t/s)^k) }),
  pwexp = { cuts <- c(seq(0, 3, by = 0.25), Inf)   # quarterly intervals (13 pieces)
    J <- length(cuts) - 1; list(k = J, H0 = function(p, t) { lam <- exp(p); sapply(t, function(u) sum(lam * pmax(0, pmin(u, cuts[-1]) - cuts[-(J+1)]))) },
         lh0 = function(p, t) p[findInterval(t, cuts, left.open = TRUE)]) }
)
## frailty: "none", "individual", "shared"; tv: include phi * egfr10_c * log t (Weibull only)
negll <- function(par, base, frailty, tv = FALSE) {
  B <- bl[[base]]; k <- B$k; p <- ncol(X)
  bp <- par[1:k]; b <- par[(k+1):(k+p)]; eta <- as.vector(X %*% b)
  if (tv) { ph <- par[k+p+1]; rho <- exp(bp[2]); a <- rho + ph * d$egfr10_c
    if (any(a <= 0)) return(1e10)
    lh <- bp[1] + log(rho) + eta + (a - 1) * log(tm); H <- exp(bp[1]) * rho * exp(eta) * tm^a / a
  } else { lh <- B$lh0(bp, tm) + eta; H <- B$H0(bp, tm) * exp(eta) }
  if (frailty == "none") ll <- sum(st * lh) - sum(H) else {
    th <- exp(par[length(par)])
    if (frailty == "individual") ll <- sum(st * (lh - log1p(th * H))) - sum(log1p(th * H)) / th
    else { Hk <- tapply(H, d$hosp, sum); dk <- tapply(st, d$hosp, sum)
      ll <- sum(st * lh) + sum(dk * log(th) + lgamma(1/th + dk) - lgamma(1/th) - (1/th + dk) * log1p(th * Hk)) } }
  if (!is.finite(ll)) 1e10 else -ll
}
fitp <- function(base, frailty, tv = FALSE, start = NULL) {
  k <- bl[[base]]$k; p <- ncol(X)
  if (is.null(start)) { start <- c(switch(base, weibull = c(log(0.1), 0), loglogistic = c(log(3), log(1.5)), pwexp = rep(log(0.05), 13)), coef(m1))
    if (tv) start <- c(start, 0); if (frailty != "none") start <- c(start, log(0.2)) }
  f <- optim(start, negll, base = base, frailty = frailty, tv = tv, method = "BFGS", hessian = TRUE,
             control = list(maxit = 2000, reltol = 1e-12))
  V <- tryCatch(solve(f$hessian), error = function(e) matrix(NA, length(start), length(start)))
  nm <- c(paste0(base, "_", 1:k), X_names, if (tv) "phi_egfr", if (frailty != "none") "log_theta")
  names(f$par) <- nm; se <- suppressWarnings(sqrt(diag(V))); names(se) <- nm
  list(est = f$par, se = se, ll = -f$value, npar = length(start), conv = f$convergence)
}
res <- list()
for (b in names(bl)) for (fr in c("none", "individual", "shared")) {
  st0 <- if (fr != "none") c(res[[paste(b, "none")]]$est, log(0.2)) else NULL
  res[[paste(b, fr)]] <- fitp(b, fr, start = st0) }
res[["weibull none tv"]]       <- fitp("weibull", "none", tv = TRUE)
res[["weibull individual tv"]] <- fitp("weibull", "individual", tv = TRUE,
                                       start = c(res[["weibull none tv"]]$est, log(0.2)))
out$param <- res
saveRDS(out, "route_results.rds")
## ---- print summary
cat("\nM1 eGFR:", coef(m1)["egfr10_c"], " zph p:", zph$table["egfr10_c","p"], " global:", zph$table["GLOBAL","p"], "\n")
print(out$piece)
cat("M2:", coef(m2)[c("egfr10_c","tt(egfr10_c)")], "p tt:", summary(m2)$coefficients["tt(egfr10_c)",5], "\n")
cat("M3 theta:", m3$history[[1]]$theta, " M3 hosp theta:", m3h$history[[1]]$theta, "\n")
print(summary(m3h)$coefficients[, c(1,5,6)])
tab <- t(sapply(names(res), function(n) { r <- res[[n]]; th <- if ("log_theta" %in% names(r$est)) exp(r$est["log_theta"]) else NA
  base <- sub(" .*", "", n); fr <- strsplit(n, " ")[[1]][2]; tvx <- grepl("tv", n)
  ref <- res[[paste(base, "none", if (tvx) "tv" else "")[1]]]; if (is.null(ref)) ref <- res[[trimws(paste(base, "none", if (tvx) "tv"))]]
  lrt <- if (fr == "none") NA else max(0, 2 * (r$ll - ref$ll))
  c(ll = r$ll, AIC = -2*r$ll + 2*r$npar, theta = th, lrt = lrt, egfr = r$est["egfr10_c"], egfr_se = r$se["egfr10_c"],
    upcr = r$est["lupcr_c"], phi = if (tvx) r$est["phi_egfr"] else NA, conv = r$conv) }))
print(round(tab, 3))
write.csv(round(tab, 4), "param_table.csv")
