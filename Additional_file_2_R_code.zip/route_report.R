suppressPackageStartupMessages(library(survival))
d <- readRDS("route_analysis.rds"); o <- readRDS("route_results.rds"); P <- o$param
for (v in c("age10","egfr10","lupcr","sbp10","hb")) d[[paste0(v,"_c")]] <- d[[v]] - mean(d[[v]])
## Descriptives
hs <- table(d$hosp)
desc <- c(sprintf("Patients (complete cases) & %d \\\\", nrow(d)),
 sprintf("CKD progression events & %d \\\\", sum(d$status)),
 sprintf("Deaths before progression (censored) & %d \\\\", sum(d$death==1 & d$status==0)),
 sprintf("Median follow-up, years & %.2f \\\\", median(d$time)),
 sprintf("Hospitals (patients per hospital) & %d (%d--%d) \\\\", length(hs), min(hs), max(hs)),
 sprintf("Age, years, mean (SD) & %.1f (%.1f) \\\\", mean(d$age), sd(d$age)),
 sprintf("Male, \\%% & %.1f \\\\", 100*mean(d$male)),
 sprintf("eGFR, mL/min/1.73m$^2$, median (IQR) & %.1f (%.1f--%.1f) \\\\", median(d$eGFR), quantile(d$eGFR,.25), quantile(d$eGFR,.75)),
 sprintf("UPCR, g/gCr, median (IQR) & %.2f (%.2f--%.2f) \\\\", median(d$UPCR), quantile(d$UPCR,.25), quantile(d$UPCR,.75)),
 sprintf("Systolic BP, mmHg, mean (SD) & %.0f (%.0f) \\\\", mean(d$SBP), sd(d$SBP)),
 sprintf("Diabetes, \\%% & %.1f \\\\", 100*mean(d$diab)),
 sprintf("Haemoglobin, g/dL, mean (SD) & %.1f (%.1f) \\\\", mean(d$hb), sd(d$hb)))
writeLines(c("\\begin{tabular}{@{}lr@{}}\\toprule", desc, "\\bottomrule\\end{tabular}"), "app_desc.tex")
## Model table
m1 <- o$M1; z <- o$zph$table; m2 <- o$M2
f <- function(x, k=3) formatC(x, format="f", digits=k)
pmix <- function(l) if (is.na(l)) NA else 0.5*pchisq(l, 1, lower.tail=FALSE)
row <- function(lab, r, ref, fr) { th <- if ("log_theta" %in% names(r$est)) exp(r$est["log_theta"]) else NA
  lrt <- if (is.null(ref)) NA else max(0, 2*(r$ll-ref$ll))
  sprintf("%s & %s & %s (%s) & %s & %s & %s \\\\", lab, f(-2*r$ll+2*r$npar,1), f(r$est["egfr10_c"]), f(r$se["egfr10_c"]),
          ifelse(is.na(th), "--", f(th)), ifelse(is.na(lrt), "--", f(lrt,2)), ifelse(is.na(lrt), "--", ifelse(pmix(lrt)<0.001,"<0.001",f(pmix(lrt)))) ) }
rows <- c()
for (b in c("weibull","loglogistic","pwexp")) { bn <- c(weibull="Weibull", loglogistic="Log-logistic", pwexp="Piecewise exp.")[b]
  rows <- c(rows, row(paste0(bn,", no frailty"), P[[paste(b,"none")]], NULL),
                  row(paste0(bn,", individual frailty"), P[[paste(b,"individual")]], P[[paste(b,"none")]]),
                  row(paste0(bn,", hospital frailty"), P[[paste(b,"shared")]], P[[paste(b,"none")]]), "\\addlinespace") }
rows <- c(rows, row("Weibull + $\\phi\\log t$, no frailty (M5 without $\\theta$)", P[["weibull none tv"]], NULL),
                row("Weibull + $\\phi\\log t$, individual frailty (M5)", P[["weibull individual tv"]], P[["weibull none tv"]]))
writeLines(c("\\begin{tabular}{@{}lccccc@{}}\\toprule",
 "Parametric model & AIC & $\\hat\\beta_{\\text{eGFR}}$ (SE) & $\\hat\\theta$ & LRT $\\theta=0$ & $p$ \\\\\\midrule", rows,
 "\\bottomrule\\end{tabular}"), "app_param.tex")
## Numbers for text
pc <- o$piece
nums <- list(m1_egfr = coef(m1)["egfr10_c"], m1_se = sqrt(vcov(m1)["egfr10_c","egfr10_c"]), zph_egfr = z["egfr10_c","p"], zph_glob = z["GLOBAL","p"],
  piece = pc[,1], piece_se = pc[,3], m2_b = coef(m2)["egfr10_c"], m2_phi = coef(m2)["tt(egfr10_c)"], m2_phi_p = summary(m2)$coefficients["tt(egfr10_c)",5],
  m3 = o$M3$history[[1]]$theta, m3h = o$M3h$history[[1]]$theta, m3h_p = summary(o$M3h)$coefficients[8,6],
  m5_phi = P[["weibull individual tv"]]$est["phi_egfr"], m5n_phi = P[["weibull none tv"]]$est["phi_egfr"])
str(nums); saveRDS(nums, "nums.rds")
## Figure
pdf("fig_app.pdf", width = 9, height = 3.9); par(mfrow = c(1,2), mar = c(4,4.2,2.2,1))
zz <- cox.zph(m1, transform = "log"); j <- which(colnames(zz$y) == "egfr10_c")
plot(zz[j], resid = FALSE, se = TRUE, lwd = 2, xlab = "Years (log scale)", ylab = "log HR per 10 mL/min eGFR",
     main = "(a) Effect of eGFR over follow-up", ylim = c(-1.4, 0.5), col = "grey30")
abline(h = coef(m1)["egfr10_c"], lty = 3); abline(h = 0, col = "grey")
tt <- seq(0.4, 3.2, length = 100); lines(tt, coef(m2)["egfr10_c"] + coef(m2)["tt(egfr10_c)"] * log(tt), col = 2, lwd = 2)
mid <- c(0.6, 1.5, 2.6); points(mid, pc[,1], pch = 19, col = 4); arrows(mid, pc[,1]-1.96*pc[,3], mid, pc[,1]+1.96*pc[,3], angle = 90, code = 3, length = .03, col = 4)
legend("topright", c("smoothed Schoenfeld (M1)", "M2: beta + phi log t", "piecewise (0-1, 1-2, >2 y)", "M1 constant"), col = c("grey30", 2, 4, 1), lty = c(1,1,NA,3), pch = c(NA,NA,19,NA), lwd = c(2,2,1,1), bty = "n", cex = .75)
th_ci <- function(r) { l <- r$est["log_theta"]; s <- r$se["log_theta"]; c(exp(l), if (is.finite(s) && exp(l) > 1e-3) exp(l + c(-1.96, 1.96) * s) else c(NA, NA)) }
lab <- c("Weibull","Log-logistic","Piecewise")
ind <- t(sapply(c("weibull","loglogistic","pwexp"), function(b) th_ci(P[[paste(b,"individual")]])))
shr <- t(sapply(c("weibull","loglogistic","pwexp"), function(b) th_ci(P[[paste(b,"shared")]])))
plot(NA, xlim = c(0.5, 3.5), ylim = c(0, 1.6), xaxt = "n", xlab = "Baseline hazard", ylab = "Estimated frailty variance",
     main = "(b) Frailty variance by baseline")
axis(1, 1:3, lab)
points(1:3 - 0.1, ind[,1], pch = 19, col = 2); arrows(1:3 - 0.1, ind[,2], 1:3 - 0.1, ind[,3], angle = 90, code = 3, length = .03, col = 2)
points(1:3 + 0.1, shr[,1], pch = 17, col = 4); arrows(1:3 + 0.1, shr[,2], 1:3 + 0.1, shr[,3], angle = 90, code = 3, length = .03, col = 4)
legend("topright", c("individual frailty", "hospital (shared) frailty"), col = c(2,4), pch = c(19,17), bty = "n", cex = .8)
dev.off()
print(ind); print(shr)
