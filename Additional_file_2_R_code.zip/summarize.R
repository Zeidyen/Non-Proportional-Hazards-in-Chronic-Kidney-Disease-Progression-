SC <- readRDS("scenarios.rds"); NN <- as.integer(commandArgs(TRUE)[1])
SC <- SC[file.exists(sprintf("long_n%d_%s.csv", NN, SC$scenario)), ]
L <- do.call(rbind, lapply(SC$scenario, function(s) read.csv(sprintf("long_n%d_%s.csv", NN, s))))
R <- length(unique(L$rep))
truth <- function(sc, p) { i <- match(sc, SC$scenario)
  switch(p, age_z=.30, egfr_z=-.60, sbp_z=.20, diab=.50, phi_diab=SC$phi[i], theta=SC$theta[i], NA) }
f <- function(x, d=3) formatC(x, format="f", digits=d)
perf <- function(sc, m, p) {
  x <- L[L$scenario==sc & L$method==m & L$parameter==p, ]
  if (!nrow(x)) return(NULL); tr <- truth(sc, p); ok <- is.finite(x$est)
  est <- x$est[ok]; se <- x$se[ok]
  cov <- mean(abs(est - tr) <= 1.96*se, na.rm=TRUE)
  c(bias=mean(est)-tr, mcse=sd(est)/sqrt(length(est)), empse=sd(est), cov=cov, n=length(est)) }
## theta: from M5 / M4 log_theta, M3 theta
theta_perf <- function(sc, m) { tr <- truth(sc,"theta")
  if (m=="M3") { x <- L[L$scenario==sc & L$method=="M3" & L$parameter=="theta",]; e <- x$est; cv <- NA }
  else { x <- L[L$scenario==sc & L$method==m & L$parameter=="log_theta",]; e <- exp(x$est)
    cv <- if (tr>0) mean(abs(x$est-log(tr)) <= 1.96*x$se, na.rm=TRUE) else NA }
  c(mean=mean(e), median=median(e), cov=cv) }
## ---- Table: scenarios with achieved censoring
cens <- sapply(SC$scenario, function(s){ r <- readRDS(sprintf("raw_n%d_%s.rds",NN,s)); mean(sapply(r, `[[`, "cens"))})
writeLines(c("\\begin{tabular}{@{}llcccc@{}}\\toprule",
 "Scenario & Description & $\\theta$ & $\\phi$ & $\\kappa$ & Censoring (pilot)\\\\\\midrule",
 sprintf("%s & %s & %.1f & %.1f & %.4f & %.1f\\%% \\\\", SC$scenario, SC$label, SC$theta, SC$phi, SC$kappa, 100*cens),
 "\\bottomrule\\end{tabular}"), sprintf("scenario_table_n%d.tex", NN))
## ---- Table 1: PH-test rejection (M1) and LRT for theta (M4)
rej <- function(sc, p) mean(L$est[L$scenario==sc & L$method=="M1" & L$parameter==p] < 0.05)
lrt <- function(sc) mean(L$est[L$scenario==sc & L$method=="M4" & L$parameter=="lrt_theta"] > 2.706)
t1 <- sapply(SC$scenario, function(s) c(sapply(c("zph_p_age_z","zph_p_egfr_z","zph_p_sbp_z","zph_p_diab","zph_p_GLOBAL"), function(p) rej(s,p)), lrt(s)))
tab1 <- c("\\begin{table}[h]\\centering\\small",
 sprintf("\\caption{Rejection rates at $\\alpha=0.05$ ($R=%d$, $n=%d$). Columns 3--7: \\texttt{cox.zph} tests on the standard Cox fit (M1). Last column: boundary LRT of $\\theta=0$ in the Weibull--gamma PH model (M4), critical value 2.71. Binomial MCSE $\\le %.1f$ points.}\\label{tab:rej%d}", R, NN, 100*sqrt(.25/R), NN),
 "\\begin{tabular}{@{}llcccccc@{}}\\toprule",
 "Scen. & Mechanism & Age & eGFR & SBP & Diabetes & Global & LRT $\\theta=0$\\\\\\midrule",
 sapply(seq_along(SC$scenario), function(i) paste0(SC$scenario[i]," & ",SC$label[i]," & ", paste(f(t1[,i],2), collapse=" & "), " \\\\")),
 "\\bottomrule\\end{tabular}\\end{table}")
## ---- Table 2: beta_eGFR and beta_diab
mk <- function(p, lab) { rows <- c()
  for (s in SC$scenario) { cells <- sapply(paste0("M",1:5), function(m){ r <- perf(s,m,p)
      if (is.null(r)) "--" else sprintf("%s (%s)", f(r["bias"]), f(100*r["cov"],0)) })
    rows <- c(rows, paste0(s, " & ", paste(cells, collapse=" & "), " \\\\")) }
  c(sprintf("\\multicolumn{6}{@{}l}{\\emph{%s}}\\\\", lab), rows) }
tab2 <- c("\\begin{table}[h]\\centering\\small",
 sprintf("\\caption{Bias relative to the conditional effect, with 95\\%% CI coverage (\\%%) in parentheses ($R=%d$, $n=%d$). Bias MCSE $\\approx 0.003$--$0.01$.}\\label{tab:bias%d}", R, NN, NN),
 "\\begin{tabular}{@{}lccccc@{}}\\toprule",
 "Scen. & M1 Cox & M2 Cox+tt & M3 Cox+frailty & M4 WG-PH & M5 WG+$\\phi$\\\\\\midrule",
 mk("egfr_z", "eGFR, $\\beta_G=-0.60$"), "\\midrule", mk("diab", "Diabetes, $\\beta_D=0.50$"),
 "\\midrule", mk("phi_diab", "Time-variation of diabetes effect, $\\phi$ (true 0 or $-0.4$)"),
 "\\bottomrule\\end{tabular}\\end{table}")
## ---- Table 3: theta
tab3r <- sapply(SC$scenario, function(s) { a <- theta_perf(s,"M3"); b <- theta_perf(s,"M4"); c5 <- theta_perf(s,"M5")
  sprintf("%s & %.1f & %s & %s & %s (%s) & %s (%s) \\\\", s, truth(s,"theta"), f(a["mean"]), f(a["median"]),
          f(b["median"]), ifelse(is.na(b["cov"]),"--",f(100*b["cov"],0)), f(c5["median"]), ifelse(is.na(c5["cov"]),"--",f(100*c5["cov"],0))) })
tab3 <- c("\\begin{table}[h]\\centering\\small",
 sprintf("\\caption{Frailty variance estimates ($n=%d$). M3: mean and median of the penalised-likelihood $\\hat\\theta$. M4, M5: median $\\hat\\theta$ with coverage (\\%%) of the Wald interval on the log scale (not defined when $\\theta=0$).}\\label{tab:theta%d}", NN, NN),
 "\\begin{tabular}{@{}lccccc@{}}\\toprule",
 "Scen. & True $\\theta$ & M3 mean & M3 median & M4 median (cov.) & M5 median (cov.)\\\\\\midrule", tab3r,
 "\\bottomrule\\end{tabular}\\end{table}")
writeLines(c(tab1, tab2, tab3), sprintf("results_tables_n%d.tex", NN))
save(t1, file="t1.rda"); cat(tab1, tab2, tab3, sep="\n")
