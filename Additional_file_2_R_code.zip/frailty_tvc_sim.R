## =============================================================================
##  Frailty or time-varying effects?  Simulation code
##  Conditional model:  h(t | X, Z) = Z * lambda * rho * t^(rho-1) *
##                                    exp(beta'X + phi * D * log t)
##  Z ~ Gamma(shape = 1/theta, rate = 1/theta)   (mean 1, variance theta)
##  Requires only base R + survival.
## =============================================================================
suppressPackageStartupMessages(library(survival))

## ---- True parameters --------------------------------------------------------
TRUE_PAR <- list(
  lambda = log(2) / 3^1.3,   # reference patient (all covariates 0, Z = 1): median 3 years
  rho    = 1.3,              # Weibull shape (increasing hazard)
  beta   = c(age_z = 0.30, egfr_z = -0.60, sbp_z = 0.20, diab = 0.50),
  tau    = 10                # administrative end of follow-up (years)
)

SCENARIOS <- data.frame(
  scenario = paste0("S", 1:7),
  theta    = c(0.0, 0.5, 1.0, 0.0,  0.5, 0.0, 0.5),
  phi      = c(0.0, 0.0, 0.0, -0.4, -0.4, 0.0, 0.0),
  baseline = c(rep("weibull", 5), "loglogistic", "loglogistic"),
  label    = c("PH, no frailty", "PH + frailty (0.5)", "PH + frailty (1.0)",
               "Time-varying, no frailty", "Time-varying + frailty (0.5)",
               "Log-logistic baseline, no frailty", "Log-logistic baseline + frailty (0.5)"),
  stringsAsFactors = FALSE
)
## Log-logistic baseline (misspecification scenarios): H0(t) = log(1 + (t/LL_SCALE)^LL_SHAPE)
## hazard rises then falls (peak at t = 3); reference median 3 years, as for the Weibull.
LL_SHAPE <- 2; LL_SCALE <- 3

## ---- Covariates -------------------------------------------------------------
gen_covariates <- function(n) {
  age_z  <- rnorm(n)
  egfr_z <- -0.4 * age_z + sqrt(1 - 0.4^2) * rnorm(n)   # older -> lower eGFR
  sbp_z  <-  0.3 * age_z + sqrt(1 - 0.3^2) * rnorm(n)
  diab   <- rbinom(n, 1, plogis(-0.6 + 0.4 * age_z))
  data.frame(age_z, egfr_z, sbp_z, diab)
}

## ---- Event times by inversion of the conditional cumulative hazard -----------
## H(t | X, Z) = Z * lambda * rho * exp(eta) * t^a / a,  a = rho + phi * D
## Solve H(T) = E, E ~ Exp(1)  =>  T = ( E * a / (Z * lambda * rho * exp(eta)) )^(1/a)
gen_event_times <- function(X, z, theta, phi, par = TRUE_PAR, baseline = "weibull") {
  eta <- as.vector(as.matrix(X[, names(par$beta)]) %*% par$beta)
  if (baseline == "loglogistic") {                     # phi must be 0 here
    E <- rexp(nrow(X))
    u <- E / (z * exp(eta))
    lem1 <- ifelse(u > 30, u, log(expm1(u)))          # log(exp(u) - 1), overflow-safe
    return(pmin(LL_SCALE * exp(lem1 / LL_SHAPE), 1e6)) # times beyond 1e6 y are censored anyway
  }
  a   <- par$rho + phi * X$diab
  stopifnot(all(a > 0))
  E   <- rexp(nrow(X))
  (E * a / (z * par$lambda * par$rho * exp(eta)))^(1 / a)
}

gen_frailty <- function(n, theta) {
  if (theta == 0) rep(1, n) else rgamma(n, shape = 1 / theta, rate = 1 / theta)
}

## ---- Censoring calibration: C = min(Exp(kappa), tau), target censoring ------
calibrate_kappa <- function(theta, phi, target = 0.35, n = 2e5, seed = 99, baseline = "weibull") {
  set.seed(seed)
  X <- gen_covariates(n); z <- gen_frailty(n, theta)
  Tt <- gen_event_times(X, z, theta, phi, baseline = baseline)
  cens_prop <- function(kappa) {
    C <- pmin(rexp(n, kappa), TRUE_PAR$tau)
    mean(Tt > C)
  }
  set.seed(seed + 1)
  base <- mean(Tt > TRUE_PAR$tau)
  if (base >= target) return(1e-8)                     # admin censoring alone suffices
  uniroot(function(k) { set.seed(seed + 1); cens_prop(k) - target },
          c(1e-6, 5))$root
}

## ---- One simulated data set ----------------------------------------------------
simulate_dataset <- function(n, theta, phi, kappa, keep_latent = TRUE, baseline = "weibull") {
  X  <- gen_covariates(n)
  z  <- gen_frailty(n, theta)
  Tt <- gen_event_times(X, z, theta, phi, baseline = baseline)
  C  <- pmin(rexp(n, kappa), TRUE_PAR$tau)
  d  <- data.frame(id = seq_len(n), X,
                   age  = round(58 + 12 * X$age_z, 1),      # clinical scale (for display)
                   egfr = round(45 + 15 * X$egfr_z, 1),
                   sbp  = round(140 + 18 * X$sbp_z, 1),
                   time = pmin(Tt, C), status = as.integer(Tt <= C))
  if (keep_latent) { d$z_true <- z; d$t_event_true <- Tt; d$c_true <- C }
  d
}

## ---- Marginal (population-averaged) quantities: Proposition 1 ---------------
cumhaz_cond <- function(t, X, phi, par = TRUE_PAR, baseline = "weibull") {
  eta <- as.vector(as.matrix(X[, names(par$beta)]) %*% par$beta)
  if (baseline == "loglogistic") return(exp(eta) * log1p((t / LL_SCALE)^LL_SHAPE))
  a   <- par$rho + phi * X$diab
  par$lambda * par$rho * exp(eta) * t^a / a
}
surv_marg <- function(t, X, theta, phi, baseline = "weibull") {
  H <- cumhaz_cond(t, X, phi, baseline = baseline)
  if (theta == 0) exp(-H) else (1 + theta * H)^(-1 / theta)
}

## ---- Parametric Weibull-gamma marginal likelihood (M4 / M5) -----------------
## par = (log lambda, log rho, beta[1:p], [phi], [log theta])
wg_negloglik <- function(par, time, status, X, W = NULL, frailty = TRUE) {
  p <- ncol(X); q <- if (is.null(W)) 0 else ncol(W)
  lam <- exp(par[1]); rho <- exp(par[2]); b <- par[3:(2 + p)]
  ph  <- if (q > 0) par[(3 + p):(2 + p + q)] else numeric(0)
  eta <- as.vector(X %*% b)
  a   <- rho + if (q > 0) as.vector(W %*% ph) else 0
  if (any(a <= 0)) return(1e10)
  logh <- log(lam) + log(rho) + eta + (a - 1) * log(time)
  H    <- lam * rho * exp(eta) * time^a / a
  if (frailty) {
    th <- exp(par[length(par)])
    ll <- sum(status * (logh - log1p(th * H))) - sum(log1p(th * H)) / th
  } else ll <- sum(status * logh) - sum(H)
  if (!is.finite(ll)) return(1e10)
  -ll
}

fit_weibull_gamma <- function(d, covs, tv = NULL, frailty = TRUE) {
  X <- as.matrix(d[, covs]); W <- if (is.null(tv)) NULL else as.matrix(d[, tv, drop = FALSE])
  sr <- survreg(Surv(time, status) ~ ., data = d[, c("time", "status", covs)], dist = "weibull")
  start <- c(-coef(sr)[1] / sr$scale, log(1 / sr$scale), -coef(sr)[-1] / sr$scale)
  if (!is.null(tv)) start <- c(start, rep(0, length(tv)))
  if (frailty) start <- c(start, log(0.3))
  fit <- try(optim(start, wg_negloglik, time = d$time, status = d$status, X = X, W = W,
                   frailty = frailty, method = "BFGS", hessian = TRUE,
                   control = list(maxit = 500, reltol = 1e-10)), silent = TRUE)
  nm <- c("log_lambda", "log_rho", covs, if (!is.null(tv)) paste0("phi_", tv),
          if (frailty) "log_theta")
  if (inherits(fit, "try-error")) return(NULL)
  V  <- try(solve(fit$hessian), silent = TRUE)
  se <- if (inherits(V, "try-error") || any(diag(V) < 0)) rep(NA, length(start)) else sqrt(diag(V))
  names(fit$par) <- names(se) <- nm
  list(est = fit$par, se = se, loglik = -fit$value, conv = fit$convergence)
}

## ---- Fit all estimators to one data set -------------------------------------
COVS <- c("age_z", "egfr_z", "sbp_z", "diab")

fit_all <- function(d) {
  f <- Surv(time, status) ~ age_z + egfr_z + sbp_z + diab
  out <- list()
  ## M1 standard Cox
  m1 <- coxph(f, data = d)
  zp <- cox.zph(m1, transform = "km")$table
  out$M1 <- list(est = coef(m1), se = sqrt(diag(vcov(m1))),
                 zph_p = zp[, "p"])
  ## M2 Cox + tt(diab * log t)
  m2 <- coxph(Surv(time, status) ~ age_z + egfr_z + sbp_z + diab + tt(diab), data = d,
              tt = function(x, t, ...) x * log(t))
  e2 <- coef(m2); names(e2)[5] <- "phi_diab"
  out$M2 <- list(est = e2, se = setNames(sqrt(diag(vcov(m2))), names(e2)))
  ## M3 Cox + individual gamma frailty (penalised partial likelihood)
  m3 <- try(suppressWarnings(coxph(Surv(time, status) ~ age_z + egfr_z + sbp_z + diab +
                                     frailty(id, distribution = "gamma"), data = d)), silent = TRUE)
  if (!inherits(m3, "try-error")) {
    b3 <- coef(m3)[COVS]
    out$M3 <- list(est = c(b3, theta = m3$history[[1]]$theta),
                   se = c(setNames(sqrt(diag(m3$var))[seq_along(COVS)], COVS), theta = NA))
  }
  ## M4 Weibull-gamma, PH;  M5 Weibull-gamma + phi*diab*log t
  m4 <- fit_weibull_gamma(d, COVS, tv = NULL)
  m5 <- fit_weibull_gamma(d, COVS, tv = "diab")
  m4w <- fit_weibull_gamma(d, COVS, tv = NULL, frailty = FALSE)   # for LRT of theta
  if (!is.null(m4)) { out$M4 <- m4; if (!is.null(m4w))
    out$M4$lrt_theta <- max(0, 2 * (m4$loglik - m4w$loglik)) }
  if (!is.null(m5)) out$M5 <- m5
  out
}

## ---- Simulation driver ------------------------------------------------------
run_scenario <- function(sc, n, nsim, kappa, seed) {
  set.seed(seed)
  res <- vector("list", nsim)
  for (r in seq_len(nsim)) {
    d <- simulate_dataset(n, sc$theta, sc$phi, kappa, keep_latent = FALSE, baseline = sc$baseline)
    res[[r]] <- c(list(rep = r, cens = 1 - mean(d$status)), fit_all(d))
  }
  res
}

## Flatten results to long format: scenario, rep, method, parameter, est, se
flatten <- function(res, sc) {
  rows <- list()
  for (x in res) for (m in c("M1", "M2", "M3", "M4", "M5")) {
    f <- x[[m]]; if (is.null(f)) next
    rows[[length(rows) + 1]] <- data.frame(scenario = sc, rep = x$rep, method = m,
      parameter = names(f$est), est = unname(f$est), se = unname(f$se[names(f$est)]),
      stringsAsFactors = FALSE)
    if (m == "M1") rows[[length(rows) + 1]] <- data.frame(scenario = sc, rep = x$rep,
      method = m, parameter = paste0("zph_p_", rownames(as.matrix(f$zph_p))),
      est = unname(f$zph_p), se = NA)
    if (m == "M4" && !is.null(f$lrt_theta)) rows[[length(rows) + 1]] <- data.frame(
      scenario = sc, rep = x$rep, method = m, parameter = "lrt_theta", est = f$lrt_theta, se = NA)
  }
  do.call(rbind, rows)
}
