## Usage: Rscript run_mc.R <nsim> <n> <scenario ids, e.g. 1,2,3>  -> long_n<n>_S*.csv
source("frailty_tvc_sim.R")
SC <- SCENARIOS
if (file.exists("kappa.rds")) SC$kappa <- readRDS("kappa.rds") else {
  SC$kappa <- sapply(seq_len(nrow(SC)), function(i) calibrate_kappa(SC$theta[i], SC$phi[i], baseline = SC$baseline[i]))
  saveRDS(SC$kappa, "kappa.rds") }
saveRDS(SC, "scenarios.rds")
a <- commandArgs(TRUE); nsim <- as.integer(a[1]); n <- as.integer(a[2])
ids <- if (length(a) > 2) as.integer(strsplit(a[3], ",")[[1]]) else seq_len(nrow(SC))
for (i in ids) {
  res <- run_scenario(SC[i,], n, nsim, SC$kappa[i], seed = 1000*i + n)
  saveRDS(res, sprintf("raw_n%d_%s.rds", n, SC$scenario[i]))
  write.csv(flatten(res, SC$scenario[i]), sprintf("long_n%d_%s.csv", n, SC$scenario[i]), row.names = FALSE)
  cat("n", n, SC$scenario[i], "done", format(Sys.time()), "\n")
}
