## Run first: python3 -c "import pandas as pd; d=pd.read_excel('ROUTE_proteinuria_dataset.xlsx'); d.columns=[c.replace('\u2265','ge').replace('%','pct').replace(' ','_').replace('(','').replace(')','').replace('-','_') for c in d.columns]; d.to_csv('route.csv',index=False)"
suppressPackageStartupMessages(library(survival))
r <- read.csv("route.csv", check.names = TRUE)
r <- subset(r, ge6M_followed == 1)
r$hosp   <- r$ID %/% 10000                     # hospital code inferred from ID prefix (16 groups)
r$time   <- r$CKD_progression_duration / 12    # years
r$status <- r$CKD_progression                  # >=50% eGFR loss or RRT; death censored (cause-specific)
r$age10  <- r$age / 10
r$male   <- as.integer(r$gender == 1)
r$egfr10 <- r$eGFR / 10
r$lupcr  <- log2(r$UPCR + 0.1)                 # offset 0.1 g/gCr: 54 values recorded as 0
r$sbp10  <- r$SBP / 10
r$diab   <- r$diabetes
r$hb     <- r$Hb
covs <- c("age10","male","egfr10","lupcr","sbp10","diab","hb")
d <- r[complete.cases(r[, c("time","status",covs)]) & r$time > 0, c("ID","hosp","time","status","death",covs,"age","eGFR","UPCR","SBP")]
saveRDS(d, "route_analysis.rds")
cat("n =", nrow(d), " events =", sum(d$status), " deaths (censored) =", sum(d$death & !d$status), " hospitals =", length(unique(d$hosp)), "\n")
cat("median follow-up (y):", median(d$time), "\n")
m1 <- coxph(Surv(time, status) ~ age10 + male + egfr10 + lupcr + sbp10 + diab + hb, data = d)
print(summary(m1)$coefficients[, c(1,2,3,5)])
print(cox.zph(m1, transform = "km"))
print(cox.zph(m1, transform = "log"))
