## Numerical study of the model (no data): Propositions 1-2, Lemma 3, Corollary (hazard peak)
source("frailty_tvc_sim.R")
lam <- function(rho) log(2)/3^rho        # reference median 3 y for any rho
bD <- TRUE_PAR$beta["diab"]; rho0 <- TRUE_PAR$rho
H  <- function(t, eta, rho=rho0, phi=0) lam(rho)*rho*exp(eta)*t^(rho+phi)/(rho+phi)
hc <- function(t, eta, rho=rho0, phi=0) lam(rho)*rho*exp(eta)*t^(rho+phi-1)
hm <- function(t, eta, th, rho=rho0, phi=0) hc(t,eta,rho,phi)/(1+th*H(t,eta,rho,phi))
lhr <- function(t, th, D=bD, rho=rho0, phi=0) log(hm(t,D,th,rho,phi)/hm(t,0,th,rho,0))
tt <- seq(0.01, 10, length=500); ths <- c(0,.25,.5,1,2); cols <- c(1,3,2,4,6)

pdf("fig_numerical_1.pdf", width=9, height=7.5); par(mfrow=c(2,2), mar=c(4,4,2.2,1))
## (a) marginal hazard, reference patient
plot(NA, xlim=c(0,10), ylim=c(0,0.45), xlab="Years", ylab="Marginal hazard", main="(a) Marginal hazard, reference patient")
for (k in seq_along(ths)) { lines(tt, hm(tt,0,ths[k]), col=cols[k], lwd=2)
  if (ths[k]>0) { ts <- ((rho0-1)/(ths[k]*lam(rho0)))^(1/rho0); if (ts<10) points(ts, hm(ts,0,ths[k]), pch=19, col=cols[k]) } }
legend("topleft", paste0("theta=",ths), col=cols, lwd=2, bty="n", cex=.8)
## (b) mean frailty among survivors
plot(NA, xlim=c(0,10), ylim=c(0,1), xlab="Years", ylab="E[Z | T > t]", main="(b) Mean frailty among survivors")
for (th in c(.5,1)) for (e in c(-1,1)) lines(tt, 1/(1+th*H(tt,e)), lwd=2, col=ifelse(e>0,2,4), lty=ifelse(th==.5,1,2))
legend("bottomleft", c("high risk (eta=+1)","low risk (eta=-1)","theta=0.5","theta=1"), col=c(2,4,1,1), lty=c(1,1,1,2), lwd=2, bty="n", cex=.8)
## (c) attenuation fraction at t = 5 over (theta, conditional HR)
thg <- seq(0, 2, length=81); hrg <- seq(1.1, 5, length=80)
A <- outer(thg, hrg, Vectorize(function(th, hr) lhr(5, th, D=log(hr))/log(hr)))
image(thg, hrg, A, col=hcl.colors(30,"YlOrRd",rev=TRUE), xlab="Frailty variance theta", ylab="Conditional hazard ratio",
      main="(c) Share of log-HR remaining at 5 years", zlim=c(0,1)); contour(thg, hrg, A, add=TRUE, levels=seq(.1,.9,.1), labcex=.7)
## (d) sensitivity to Weibull shape
plot(NA, xlim=c(0,2), ylim=c(0,1), xlab="Frailty variance theta", ylab="Share of log-HR remaining at 5 years", main="(d) Sensitivity to baseline shape (HR = 1.65)")
rhos <- c(.8,1,1.3,2); for (k in seq_along(rhos)) lines(thg, sapply(thg, function(th) lhr(5,th,rho=rhos[k])/bD), lwd=2, col=k)
legend("topright", paste0("rho=",rhos), col=seq_along(rhos), lwd=2, bty="n", cex=.8)
dev.off()

## Distinguishability: best frailty-free (beta0 + phi log t) approximation to frailty-induced log-HR
fD <- function(t, th) hm(t,bD,th)*(1+th*H(t,bD))^(-1/th)   # marginal event density, diabetics
equiv <- t(sapply(c(.25,.5,1,2), function(th) {
  w <- fD(tt, th); y <- lhr(tt, th); x <- log(tt)
  f <- lm(y ~ x, weights = w); r <- sqrt(weighted.mean(resid(f)^2, w))
  c(theta=th, beta0=unname(coef(f)[1]), phi=unname(coef(f)[2]), rms=r) }))
print(equiv)
pdf("fig_numerical_2.pdf", width=9, height=3.8); par(mfrow=c(1,2), mar=c(4,4,2.2,1))
plot(NA, xlim=c(0,10), ylim=c(-0.1,0.85), xlab="Years", ylab="Marginal log hazard ratio (diabetes)", main="(a) Frailty vs best time-varying mimic")
for (k in 1:4) { th <- equiv[k,1]; lines(tt, lhr(tt,th), col=k+1, lwd=2)
  lines(tt, equiv[k,2]+equiv[k,3]*log(tt), col=k+1, lty=2) }
abline(h=c(0,bD), col="grey"); legend("topright", c(paste0("theta=",equiv[,1]), "solid: frailty, PH", "dashed: phi*log t, no frailty"),
  col=c(2:5,1,1), lty=c(1,1,1,1,1,2), lwd=c(2,2,2,2,1,1), bty="n", cex=.75)
## (b) peak time of marginal hazard
thp <- seq(0.05, 2, length=200)
plot(thp, ((rho0-1)/(thp*lam(rho0)))^(1/rho0), type="l", lwd=2, log="y", xlab="Frailty variance theta", ylab="Peak of marginal hazard (years, log scale)",
     main="(b) Time at which the marginal hazard peaks"); abline(h=10, lty=3); text(1.6, 12, "end of follow-up", cex=.75)
dev.off()
tab <- c("\\begin{tabular}{@{}ccccc@{}}\\toprule",
 "$\\theta$ & Mimic $\\beta_0$ & Mimic $\\phi$ & Weighted RMS gap & Hazard peak $t^*$ (y)\\\\\\midrule",
 apply(equiv, 1, function(r) sprintf("%.2f & %.3f & %.3f & %.4f & %.1f \\\\", r[1], r[2], r[3], r[4], ((rho0-1)/(r[1]*lam(rho0)))^(1/rho0))),
 "\\bottomrule\\end{tabular}")
writeLines(tab, "numerical_table.tex")
